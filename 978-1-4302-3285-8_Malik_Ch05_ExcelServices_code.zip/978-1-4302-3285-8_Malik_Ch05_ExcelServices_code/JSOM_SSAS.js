<script type="text/javascript"> 

var ewaWebPart = null; 

if(window.attachEvent)
{ 
    window.attachEvent("onload", Page_Load); 
} 

function Page_Load() 
{
    Ewa.EwaControl.add_applicationReady(GetEwaWebpart); 
} 

function GetEwaWebpart() 
{ 
    ewaWebPart = Ewa.EwaControl.getInstances().getItem(0); 

    if(ewaWebPart) 
    {
        ewaWebPart.add_activeSelectionChanged(activeSelectionChangedHandler); 
    } 
} 

function activeSelectionChangedHandler(rangeArgs) 
{
 
    var selection = rangeArgs.getRange(); 
    var selectedSheet = selection.getSheet().getName(); 
    var selectedValues = rangeArgs.getFormattedValues(); 


    if(selectedSheet = "Sheet1") 
    { 
        document.getElementById('ewaText').firstChild.data = selectedValues;   
    } 
} 

</script> 
<div id="ewaText" style="font-family: Verdana; font-style: bold; font-size:14pt; color:red;">&nbsp;</div>

