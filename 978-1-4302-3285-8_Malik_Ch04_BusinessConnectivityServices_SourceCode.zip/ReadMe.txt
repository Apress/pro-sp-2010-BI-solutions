EmployeeEntityModel - Consists of project to create author ECT using visual studio and custom .net connector
\EmployeeEntityModel\Stored Procedures - Consists of Stored Procedures used for under the above project

BCSRunTime - Contains project code to demonstrate BCS Runtime object model

Word Integration - Contains document integrated with ECT.