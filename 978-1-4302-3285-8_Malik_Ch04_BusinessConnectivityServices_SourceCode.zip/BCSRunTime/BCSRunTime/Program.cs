﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.SharePoint;

using Microsoft.SharePoint.BusinessData.SharedService;
using Microsoft.SharePoint.BusinessData.MetadataModel;

using Microsoft.BusinessData.MetadataModel;
using Microsoft.BusinessData.Runtime;

namespace BCSRunTime
{
    class Program
    {
        static void Main(string[] args)
        {
            ExecuteBcsEctMethods(@"http://yoursharepointsite/");
        }

        static void ExecuteBcsEctMethods(string siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (new SPServiceContextScope(SPServiceContext.GetContext(site)))
                {                  
                    BdcServiceApplicationProxy proxy = (BdcServiceApplicationProxy)SPServiceContext.Current.GetDefaultProxy(typeof(BdcServiceApplicationProxy));
                    DatabaseBackedMetadataCatalog model = proxy.GetDatabaseBackedMetadataCatalog();

                    IEntity entity = model.GetEntity("EmployeeEntityModel", "Entity1");
                    ILobSystemInstance lobSystemInstance = entity.GetLobSystem().GetLobSystemInstances()[0].Value;
                    IMethodInstance method = entity.GetMethodInstance("ReadList", MethodInstanceType.Finder);
                    IView view = entity.GetFinderView(method.Name);               
                    IFilterCollection filterCollection = entity.GetDefaultFinderFilters();
                    IEntityInstanceEnumerator entityInstanceEnumerator = entity.FindFiltered(filterCollection, method.Name, lobSystemInstance, OperationMode.Online);

                    Console.WriteLine("Employee Login ID | Title");
                    while (entityInstanceEnumerator.MoveNext())
                    {
                        Console.WriteLine(entityInstanceEnumerator.Current["LoginID"].ToString() + " - " + entityInstanceEnumerator.Current["Title"].ToString());
                    }
                    Console.ReadLine();
                }
            }
        }
    }
}
